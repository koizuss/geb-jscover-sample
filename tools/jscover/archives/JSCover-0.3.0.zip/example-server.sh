#java -jar target/dist/JSCover.jar -ws --document-root=doc/example --report-dir=target
java -jar target/dist/JSCover-all.jar -ws --document-root=doc/example --report-dir=target
