var x = 0;
if (x > 0)
    x--;
function fn(x){return x+1;}
x = fn(x);