var no = 0;
if (no > 0)
    no--;