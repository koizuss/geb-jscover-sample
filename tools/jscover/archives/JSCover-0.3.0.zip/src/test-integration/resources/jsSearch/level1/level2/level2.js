var z = 0;
function fn(z) {
    if (z > 0)
        z--;
}