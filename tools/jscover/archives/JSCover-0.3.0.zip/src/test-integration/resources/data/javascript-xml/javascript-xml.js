// ECMA 357 11.1.4
// an XML object representing a person with a name and age
var person = <person><name>John</name><age>25</age></person>;
// a variable containing an XML object representing two employees
var e = <employees>
   <employee id="1"><name>Joe</name><age>20</age></employee>
   <employee id="2"><name>Sue</name><age>30</age></employee>
</employees>;
