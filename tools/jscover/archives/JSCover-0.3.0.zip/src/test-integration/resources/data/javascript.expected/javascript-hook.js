if (! _$jscoverage['javascript-hook.js']) {
  _$jscoverage['javascript-hook.js'] = {};
  _$jscoverage['javascript-hook.js'].lineData = [];
  _$jscoverage['javascript-hook.js'].lineData[1] = 0;
  _$jscoverage['javascript-hook.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-hook.js'].functionData) {
  _$jscoverage['javascript-hook.js'].functionData = [];
}
_$jscoverage['javascript-hook.js'].lineData[1]++;
var x = 1;
_$jscoverage['javascript-hook.js'].lineData[2]++;
var y = x === 1 ? "x" : "y";
