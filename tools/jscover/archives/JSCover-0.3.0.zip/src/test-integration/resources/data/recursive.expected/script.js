if (! _$jscoverage['@PREFIX@script.js']) {
  _$jscoverage['@PREFIX@script.js'] = [];
  _$jscoverage['@PREFIX@script.js'][1] = 0;
  _$jscoverage['@PREFIX@script.js'][4] = 0;
  _$jscoverage['@PREFIX@script.js'][5] = 0;
}
_$jscoverage['@PREFIX@script.js'][1]++;
alert("hello");
_$jscoverage['@PREFIX@script.js'][4]++;
if ((("a" < "b") && ("a" > "b"))) {
  _$jscoverage['@PREFIX@script.js'][5]++;
  alert("?");
}
