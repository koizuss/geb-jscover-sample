if (! _$jscoverage['javascript-lf.js']) {
  _$jscoverage['javascript-lf.js'] = {};
  _$jscoverage['javascript-lf.js'].lineData = [];
  _$jscoverage['javascript-lf.js'].lineData[4] = 0;
}
if (! _$jscoverage['javascript-lf.js'].functionData) {
  _$jscoverage['javascript-lf.js'].functionData = [];
}
_$jscoverage['javascript-lf.js'].lineData[4]++;
var x = 1;
