
someObject
    .mouseenter(
    function() {
        x++;
    }
).click(
    function() {
        x--;
    }
);