if (! _$jscoverage['javascript-while.js']) {
  _$jscoverage['javascript-while.js'] = {};
  _$jscoverage['javascript-while.js'].lineData = [];
  _$jscoverage['javascript-while.js'].lineData[1] = 0;
  _$jscoverage['javascript-while.js'].lineData[2] = 0;
  _$jscoverage['javascript-while.js'].lineData[5] = 0;
  _$jscoverage['javascript-while.js'].lineData[6] = 0;
  _$jscoverage['javascript-while.js'].lineData[9] = 0;
  _$jscoverage['javascript-while.js'].lineData[10] = 0;
  _$jscoverage['javascript-while.js'].lineData[12] = 0;
  _$jscoverage['javascript-while.js'].lineData[13] = 0;
  _$jscoverage['javascript-while.js'].lineData[15] = 0;
  _$jscoverage['javascript-while.js'].lineData[16] = 0;
  _$jscoverage['javascript-while.js'].lineData[17] = 0;
  _$jscoverage['javascript-while.js'].lineData[21] = 0;
  _$jscoverage['javascript-while.js'].lineData[23] = 0;
  _$jscoverage['javascript-while.js'].lineData[24] = 0;
  _$jscoverage['javascript-while.js'].lineData[28] = 0;
  _$jscoverage['javascript-while.js'].lineData[29] = 0;
  _$jscoverage['javascript-while.js'].lineData[30] = 0;
  _$jscoverage['javascript-while.js'].lineData[31] = 0;
  _$jscoverage['javascript-while.js'].lineData[32] = 0;
}
if (! _$jscoverage['javascript-while.js'].functionData) {
  _$jscoverage['javascript-while.js'].functionData = [];
}
_$jscoverage['javascript-while.js'].lineData[1]++;
while (x) {
  _$jscoverage['javascript-while.js'].lineData[2]++;
  x();
}
_$jscoverage['javascript-while.js'].lineData[5]++;
while (x) {
  _$jscoverage['javascript-while.js'].lineData[6]++;
  ;
}
_$jscoverage['javascript-while.js'].lineData[9]++;
while (x) {
  _$jscoverage['javascript-while.js'].lineData[10]++;
  x();
}
_$jscoverage['javascript-while.js'].lineData[12]++;
while (x) {
  _$jscoverage['javascript-while.js'].lineData[13]++;
  ;
}
_$jscoverage['javascript-while.js'].lineData[15]++;
while (x) {
  _$jscoverage['javascript-while.js'].lineData[16]++;
  if (x) {
    _$jscoverage['javascript-while.js'].lineData[17]++;
    continue;
  }
}
_$jscoverage['javascript-while.js'].lineData[21]++;
label:
  while (x) {
    _$jscoverage['javascript-while.js'].lineData[23]++;
    if (x) {
      _$jscoverage['javascript-while.js'].lineData[24]++;
      continue label;
    }
  }
_$jscoverage['javascript-while.js'].lineData[28]++;
label2:
  {
    _$jscoverage['javascript-while.js'].lineData[29]++;
    f();
    _$jscoverage['javascript-while.js'].lineData[30]++;
    while (x) {
      _$jscoverage['javascript-while.js'].lineData[31]++;
      if (x) {
        _$jscoverage['javascript-while.js'].lineData[32]++;
        break label2;
      }
    }
  }
