try {
  f();
}
catch (e) {
  debugger;
}
