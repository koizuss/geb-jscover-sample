x = true;
x = false;
x = null;
x = this;
