if (! _$jscoverage['javascript-inc.js']) {
  _$jscoverage['javascript-inc.js'] = {};
  _$jscoverage['javascript-inc.js'].lineData = [];
  _$jscoverage['javascript-inc.js'].lineData[1] = 0;
  _$jscoverage['javascript-inc.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-inc.js'].functionData) {
  _$jscoverage['javascript-inc.js'].functionData = [];
}
_$jscoverage['javascript-inc.js'].lineData[1]++;
x++;
_$jscoverage['javascript-inc.js'].lineData[2]++;
++x;
