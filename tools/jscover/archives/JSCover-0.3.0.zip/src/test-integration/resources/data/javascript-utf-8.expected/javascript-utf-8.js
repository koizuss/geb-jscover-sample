if (! _$jscoverage['javascript-utf-8.js']) {
  _$jscoverage['javascript-utf-8.js'] = [];
  _$jscoverage['javascript-utf-8.js'][1] = 0;
  _$jscoverage['javascript-utf-8.js'][2] = 0;
}
_$jscoverage['javascript-utf-8.js'][1]++;
var s = "e\u00e8\u00e9\u00ea";
_$jscoverage['javascript-utf-8.js'][2]++;
var r = /e\u00e8\u00e9\u00ea/;
