if (! _$jscoverage['javascript-function.js']) {
  _$jscoverage['javascript-function.js'] = {};
  _$jscoverage['javascript-function.js'].lineData = [];
  _$jscoverage['javascript-function.js'].lineData[1] = 0;
  _$jscoverage['javascript-function.js'].lineData[3] = 0;
  _$jscoverage['javascript-function.js'].lineData[4] = 0;
  _$jscoverage['javascript-function.js'].lineData[7] = 0;
  _$jscoverage['javascript-function.js'].lineData[8] = 0;
  _$jscoverage['javascript-function.js'].lineData[9] = 0;
  _$jscoverage['javascript-function.js'].lineData[12] = 0;
  _$jscoverage['javascript-function.js'].lineData[13] = 0;
  _$jscoverage['javascript-function.js'].lineData[16] = 0;
  _$jscoverage['javascript-function.js'].lineData[17] = 0;
  _$jscoverage['javascript-function.js'].lineData[20] = 0;
  _$jscoverage['javascript-function.js'].lineData[21] = 0;
  _$jscoverage['javascript-function.js'].lineData[24] = 0;
  _$jscoverage['javascript-function.js'].lineData[25] = 0;
  _$jscoverage['javascript-function.js'].lineData[28] = 0;
  _$jscoverage['javascript-function.js'].lineData[29] = 0;
  _$jscoverage['javascript-function.js'].lineData[32] = 0;
  _$jscoverage['javascript-function.js'].lineData[33] = 0;
  _$jscoverage['javascript-function.js'].lineData[36] = 0;
  _$jscoverage['javascript-function.js'].lineData[37] = 0;
  _$jscoverage['javascript-function.js'].lineData[40] = 0;
  _$jscoverage['javascript-function.js'].lineData[41] = 0;
  _$jscoverage['javascript-function.js'].lineData[44] = 0;
  _$jscoverage['javascript-function.js'].lineData[45] = 0;
  _$jscoverage['javascript-function.js'].lineData[48] = 0;
  _$jscoverage['javascript-function.js'].lineData[49] = 0;
  _$jscoverage['javascript-function.js'].lineData[52] = 0;
  _$jscoverage['javascript-function.js'].lineData[53] = 0;
  _$jscoverage['javascript-function.js'].lineData[56] = 0;
  _$jscoverage['javascript-function.js'].lineData[57] = 0;
  _$jscoverage['javascript-function.js'].lineData[61] = 0;
}
if (! _$jscoverage['javascript-function.js'].functionData) {
  _$jscoverage['javascript-function.js'].functionData = [];
  _$jscoverage['javascript-function.js'].functionData[0] = 0;
  _$jscoverage['javascript-function.js'].functionData[1] = 0;
  _$jscoverage['javascript-function.js'].functionData[2] = 0;
  _$jscoverage['javascript-function.js'].functionData[3] = 0;
  _$jscoverage['javascript-function.js'].functionData[4] = 0;
  _$jscoverage['javascript-function.js'].functionData[5] = 0;
  _$jscoverage['javascript-function.js'].functionData[6] = 0;
  _$jscoverage['javascript-function.js'].functionData[7] = 0;
  _$jscoverage['javascript-function.js'].functionData[8] = 0;
  _$jscoverage['javascript-function.js'].functionData[9] = 0;
  _$jscoverage['javascript-function.js'].functionData[10] = 0;
  _$jscoverage['javascript-function.js'].functionData[11] = 0;
  _$jscoverage['javascript-function.js'].functionData[12] = 0;
  _$jscoverage['javascript-function.js'].functionData[13] = 0;
  _$jscoverage['javascript-function.js'].functionData[14] = 0;
}
_$jscoverage['javascript-function.js'].lineData[1]++;
function f() {
  _$jscoverage['javascript-function.js'].functionData[0]++;
}
_$jscoverage['javascript-function.js'].lineData[3]++;
function g() {
  _$jscoverage['javascript-function.js'].functionData[1]++;
  _$jscoverage['javascript-function.js'].lineData[4]++;
  ;
}
_$jscoverage['javascript-function.js'].lineData[7]++;
function h() {
  _$jscoverage['javascript-function.js'].functionData[2]++;
  _$jscoverage['javascript-function.js'].lineData[8]++;
  x();
  _$jscoverage['javascript-function.js'].lineData[9]++;
  return 'x';
}
_$jscoverage['javascript-function.js'].lineData[12]++;
function i(a) {
  _$jscoverage['javascript-function.js'].functionData[3]++;
  _$jscoverage['javascript-function.js'].lineData[13]++;
  x();
}
_$jscoverage['javascript-function.js'].lineData[16]++;
function j(a, b) {
  _$jscoverage['javascript-function.js'].functionData[4]++;
  _$jscoverage['javascript-function.js'].lineData[17]++;
  x();
}
_$jscoverage['javascript-function.js'].lineData[20]++;
x = function() {
  _$jscoverage['javascript-function.js'].functionData[5]++;
  _$jscoverage['javascript-function.js'].lineData[21]++;
  x();
};
_$jscoverage['javascript-function.js'].lineData[24]++;
x = function k() {
  _$jscoverage['javascript-function.js'].functionData[6]++;
  _$jscoverage['javascript-function.js'].lineData[25]++;
  x();
};
_$jscoverage['javascript-function.js'].lineData[28]++;
(function() {
  _$jscoverage['javascript-function.js'].functionData[7]++;
  _$jscoverage['javascript-function.js'].lineData[29]++;
  print('x');
})();
_$jscoverage['javascript-function.js'].lineData[32]++;
(function l() {
  _$jscoverage['javascript-function.js'].functionData[8]++;
  _$jscoverage['javascript-function.js'].lineData[33]++;
  print('x');
})();
_$jscoverage['javascript-function.js'].lineData[36]++;
(function(a) {
  _$jscoverage['javascript-function.js'].functionData[9]++;
  _$jscoverage['javascript-function.js'].lineData[37]++;
  print('x');
})(1);
_$jscoverage['javascript-function.js'].lineData[40]++;
(function m(a) {
  _$jscoverage['javascript-function.js'].functionData[10]++;
  _$jscoverage['javascript-function.js'].lineData[41]++;
  print('x');
})(1);
_$jscoverage['javascript-function.js'].lineData[44]++;
(function(a, b) {
  _$jscoverage['javascript-function.js'].functionData[11]++;
  _$jscoverage['javascript-function.js'].lineData[45]++;
  print('x');
})(1, 2);
_$jscoverage['javascript-function.js'].lineData[48]++;
(function n(a, b) {
  _$jscoverage['javascript-function.js'].functionData[12]++;
  _$jscoverage['javascript-function.js'].lineData[49]++;
  print('x');
})(1, 2);
_$jscoverage['javascript-function.js'].lineData[52]++;
(function() {
  _$jscoverage['javascript-function.js'].functionData[13]++;
  _$jscoverage['javascript-function.js'].lineData[53]++;
  print('x');
}).call(window);
_$jscoverage['javascript-function.js'].lineData[56]++;
(function o() {
  _$jscoverage['javascript-function.js'].functionData[14]++;
  _$jscoverage['javascript-function.js'].lineData[57]++;
  print('x');
}).call(window);
_$jscoverage['javascript-function.js'].lineData[61]++;
(b - a)();
