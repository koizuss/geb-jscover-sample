if (! _$jscoverage['javascript-json-object.js']) {
  _$jscoverage['javascript-json-object.js'] = {};
  _$jscoverage['javascript-json-object.js'].lineData = [];
  _$jscoverage['javascript-json-object.js'].lineData[1] = 0;
  _$jscoverage['javascript-json-object.js'].lineData[4] = 0;
}
if (! _$jscoverage['javascript-json-object.js'].functionData) {
  _$jscoverage['javascript-json-object.js'].functionData = [];
  _$jscoverage['javascript-json-object.js'].functionData[0] = 0;
}
_$jscoverage['javascript-json-object.js'].lineData[1]++;
var obj = {
  a: 'a', 
  b: function() {
  _$jscoverage['javascript-json-object.js'].functionData[0]++;
  _$jscoverage['javascript-json-object.js'].lineData[4]++;
  return 1;
}};
