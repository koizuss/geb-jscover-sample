if (! _$jscoverage['javascript-if.js']) {
  _$jscoverage['javascript-if.js'] = {};
  _$jscoverage['javascript-if.js'].lineData = [];
  _$jscoverage['javascript-if.js'].lineData[1] = 0;
  _$jscoverage['javascript-if.js'].lineData[3] = 0;
  _$jscoverage['javascript-if.js'].lineData[4] = 0;
  _$jscoverage['javascript-if.js'].lineData[6] = 0;
  _$jscoverage['javascript-if.js'].lineData[7] = 0;
  _$jscoverage['javascript-if.js'].lineData[10] = 0;
  _$jscoverage['javascript-if.js'].lineData[11] = 0;
  _$jscoverage['javascript-if.js'].lineData[13] = 0;
  _$jscoverage['javascript-if.js'].lineData[15] = 0;
  _$jscoverage['javascript-if.js'].lineData[16] = 0;
  _$jscoverage['javascript-if.js'].lineData[19] = 0;
  _$jscoverage['javascript-if.js'].lineData[22] = 0;
  _$jscoverage['javascript-if.js'].lineData[23] = 0;
  _$jscoverage['javascript-if.js'].lineData[25] = 0;
  _$jscoverage['javascript-if.js'].lineData[26] = 0;
  _$jscoverage['javascript-if.js'].lineData[29] = 0;
}
if (! _$jscoverage['javascript-if.js'].functionData) {
  _$jscoverage['javascript-if.js'].functionData = [];
}
_$jscoverage['javascript-if.js'].lineData[1]++;
var x = 0;
_$jscoverage['javascript-if.js'].lineData[3]++;
if (x) {
  _$jscoverage['javascript-if.js'].lineData[4]++;
  x = 0;
}
_$jscoverage['javascript-if.js'].lineData[6]++;
if (x) {
  _$jscoverage['javascript-if.js'].lineData[7]++;
  x = 0;
}
_$jscoverage['javascript-if.js'].lineData[10]++;
if (x) {
  _$jscoverage['javascript-if.js'].lineData[11]++;
  x = 0;
} else {
  _$jscoverage['javascript-if.js'].lineData[13]++;
  x = 0;
}
_$jscoverage['javascript-if.js'].lineData[15]++;
if (x) {
  _$jscoverage['javascript-if.js'].lineData[16]++;
  x = 0;
} else {
  _$jscoverage['javascript-if.js'].lineData[19]++;
  x = 0;
}
_$jscoverage['javascript-if.js'].lineData[22]++;
if (x) {
  _$jscoverage['javascript-if.js'].lineData[23]++;
  x = 0;
} else {
  _$jscoverage['javascript-if.js'].lineData[25]++;
  if (x) {
    _$jscoverage['javascript-if.js'].lineData[26]++;
    x = 0;
  } else {
    _$jscoverage['javascript-if.js'].lineData[29]++;
    x = 0;
  }
}
