x.y = y.x;
x["y"] = y["x"];
x[y] = y[x];
x['2y'] = y['var'];
x[''] = y[""];

print(123.0.toString());
({}.toString());
