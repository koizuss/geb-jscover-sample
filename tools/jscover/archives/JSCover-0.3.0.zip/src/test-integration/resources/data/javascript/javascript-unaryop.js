x = -x;
x = +x;
x = !x;
x = ~x;
x = typeof x;
x = typeof 123;  // this has a different pn_op value
x = void x;
