var x = {};
if ('a' in x) {
  x = null;
}
