x = {
  x: y
};
x = {
  x: y,
  y: x
};
