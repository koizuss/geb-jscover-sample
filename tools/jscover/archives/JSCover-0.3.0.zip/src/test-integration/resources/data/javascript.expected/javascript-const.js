if (! _$jscoverage['javascript-const.js']) {
  _$jscoverage['javascript-const.js'] = {};
  _$jscoverage['javascript-const.js'].lineData = [];
  _$jscoverage['javascript-const.js'].lineData[1] = 0;
  _$jscoverage['javascript-const.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-const.js'].functionData) {
  _$jscoverage['javascript-const.js'].functionData = [];
}
_$jscoverage['javascript-const.js'].lineData[1]++;
const x;
_$jscoverage['javascript-const.js'].lineData[2]++;
const y = x, z = x;
