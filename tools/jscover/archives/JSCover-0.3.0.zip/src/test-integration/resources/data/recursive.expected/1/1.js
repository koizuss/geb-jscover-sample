if (! _$jscoverage['@PREFIX@1/1.js']) {
  _$jscoverage['@PREFIX@1/1.js'] = [];
  _$jscoverage['@PREFIX@1/1.js'][1] = 0;
}
_$jscoverage['@PREFIX@1/1.js'][1]++;
alert("This is 1");
