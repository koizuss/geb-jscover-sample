x = a + (b - c);
x = a - (b + c);
