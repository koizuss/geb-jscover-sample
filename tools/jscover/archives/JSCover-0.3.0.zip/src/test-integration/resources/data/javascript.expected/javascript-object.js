if (! _$jscoverage['javascript-object.js']) {
  _$jscoverage['javascript-object.js'] = {};
  _$jscoverage['javascript-object.js'].lineData = [];
  _$jscoverage['javascript-object.js'].lineData[1] = 0;
  _$jscoverage['javascript-object.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-object.js'].functionData) {
  _$jscoverage['javascript-object.js'].functionData = [];
}
_$jscoverage['javascript-object.js'].lineData[1]++;
x = /x\(\)\\\//i;
_$jscoverage['javascript-object.js'].lineData[2]++;
y = /\u0001\u002f/gm;
