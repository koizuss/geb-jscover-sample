if (! _$jscoverage['javascript-rb.js']) {
  _$jscoverage['javascript-rb.js'] = {};
  _$jscoverage['javascript-rb.js'].lineData = [];
  _$jscoverage['javascript-rb.js'].lineData[1] = 0;
  _$jscoverage['javascript-rb.js'].lineData[2] = 0;
  _$jscoverage['javascript-rb.js'].lineData[3] = 0;
  _$jscoverage['javascript-rb.js'].lineData[4] = 0;
  _$jscoverage['javascript-rb.js'].lineData[5] = 0;
  _$jscoverage['javascript-rb.js'].lineData[6] = 0;
}
if (! _$jscoverage['javascript-rb.js'].functionData) {
  _$jscoverage['javascript-rb.js'].functionData = [];
}
_$jscoverage['javascript-rb.js'].lineData[1]++;
x = [];
_$jscoverage['javascript-rb.js'].lineData[2]++;
x = [x];
_$jscoverage['javascript-rb.js'].lineData[3]++;
x = [x, y];
_$jscoverage['javascript-rb.js'].lineData[4]++;
x = [x, y];
_$jscoverage['javascript-rb.js'].lineData[5]++;
x = [x, , y];
_$jscoverage['javascript-rb.js'].lineData[6]++;
x = [(a , b), c];
