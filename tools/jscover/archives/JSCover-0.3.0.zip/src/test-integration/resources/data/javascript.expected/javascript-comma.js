if (! _$jscoverage['javascript-comma.js']) {
  _$jscoverage['javascript-comma.js'] = {};
  _$jscoverage['javascript-comma.js'].lineData = [];
  _$jscoverage['javascript-comma.js'].lineData[1] = 0;
}
if (! _$jscoverage['javascript-comma.js'].functionData) {
  _$jscoverage['javascript-comma.js'].functionData = [];
}
_$jscoverage['javascript-comma.js'].lineData[1]++;
x = y , y = x;
