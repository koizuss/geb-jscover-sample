if (! _$jscoverage['javascript-var.js']) {
  _$jscoverage['javascript-var.js'] = {};
  _$jscoverage['javascript-var.js'].lineData = [];
  _$jscoverage['javascript-var.js'].lineData[1] = 0;
  _$jscoverage['javascript-var.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-var.js'].functionData) {
  _$jscoverage['javascript-var.js'].functionData = [];
}
_$jscoverage['javascript-var.js'].lineData[1]++;
var x;
_$jscoverage['javascript-var.js'].lineData[2]++;
var y = x, z = x;
