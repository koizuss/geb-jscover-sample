if (! _$jscoverage['javascript-do.js']) {
  _$jscoverage['javascript-do.js'] = {};
  _$jscoverage['javascript-do.js'].lineData = [];
  _$jscoverage['javascript-do.js'].lineData[1] = 0;
  _$jscoverage['javascript-do.js'].lineData[3] = 0;
  _$jscoverage['javascript-do.js'].lineData[4] = 0;
  _$jscoverage['javascript-do.js'].lineData[8] = 0;
  _$jscoverage['javascript-do.js'].lineData[9] = 0;
}
if (! _$jscoverage['javascript-do.js'].functionData) {
  _$jscoverage['javascript-do.js'].functionData = [];
}
_$jscoverage['javascript-do.js'].lineData[1]++;
var x;
_$jscoverage['javascript-do.js'].lineData[3]++;
do {
  _$jscoverage['javascript-do.js'].lineData[4]++;
  x = false;
} while (x);
_$jscoverage['javascript-do.js'].lineData[8]++;
do {
  _$jscoverage['javascript-do.js'].lineData[9]++;
  x = false;
} while (x);
