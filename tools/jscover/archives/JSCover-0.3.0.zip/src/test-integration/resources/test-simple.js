var x, y;
x = 1;
y = x * 2;