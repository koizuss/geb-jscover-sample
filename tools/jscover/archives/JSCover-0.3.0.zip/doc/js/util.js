var lastSlashIndex = document.location.href.lastIndexOf('/');
var page = document.location.href.substring(lastSlashIndex+1);
if (page.indexOf('index.html') !== 0) {
    var newPath = document.location.href.substring(0,lastSlashIndex) + '/index.html?page=' + page;
    document.location.href = newPath;
}