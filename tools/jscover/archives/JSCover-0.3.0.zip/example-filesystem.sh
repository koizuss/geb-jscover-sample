#java -jar target/dist/JSCover.jar -fs --no-instrument=test doc/example-qunit/src doc/example-qunit/out
java -jar target/dist/JSCover-all.jar -fs doc/example target/example
